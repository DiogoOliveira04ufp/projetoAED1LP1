#include "germin.h"

#include "germin.h"
#include <string.h>

void findSequences(MATRIX_STRINGS *matrix, char *current, char **path, int pathLen, int visited[], int maxLen) {
    // Print current path
    printf("%s", current);
    for (int i = 0; i < pathLen; i++) {
        printf(" --> %s", path[i]);
    }
    printf("\n");

    // Try to extend current path
    KMP *pattern;
    for (int i = 0; i < matrix->size; i++) {
        if (!visited[i]) {
            pattern = KMP_init(current);
            int pos = KMP_search(pattern, matrix->strings[i]);
            if (pos < strlen(matrix->strings[i])) {
                visited[i] = 1;
                path[pathLen] = matrix->strings[i];
                findSequences(matrix, matrix->strings[i], path, pathLen + 1, visited, maxLen);
                visited[i] = 0;
            }
            KMP_free(pattern);
        }
    }
}

void germin(MATRIX_STRINGS *matrix) {
    char **path = malloc(sizeof(char *) * matrix->size);
    int *visited = calloc(matrix->size, sizeof(int));

    for (int i = 0; i < matrix->size; i++) {
        memset(visited, 0, matrix->size * sizeof(int));
        visited[i] = 1;
        findSequences(matrix, matrix->strings[i], path, 0, visited, matrix->size);
    }

    free(path);
    free(visited);
}

/*
void germin(MATRIX_STRINGS *matrix)
{
    KMP *pattern;
    char *word;
    char **sequence = malloc(sizeof(char *) * matrix->size);
    int k = 0;

    for (int i = 0; i < matrix->size; i++)
    {
        word = matrix->strings[i];
        k = 0;
        for (int j = 0; j < matrix->size; j++)
        {
            if (matrix->strings[j] != word)
            {
                pattern = KMP_init(word);
                int pos = KMP_search(pattern, matrix->strings[j]);
                if (pos < strlen(matrix->strings[j]))
                {
                    sequence[k] = matrix->strings[j];
                    k++;
                    word = matrix->strings[j];
                }
                KMP_free(pattern);
            }
        }

        printf("%s-->", matrix->strings[i]);
        for (int j = 0; j < k; j++)
        {
            if (j == k - 1)
            {
                printf("%s", sequence[j]);
            }
            else
            {
                printf("%s-->", sequence[j]);
            }
        }
        printf("\n"); // End of sequence
    }

    free(sequence);
}
*/
