#include <stdio.h>
#include "tests.h"

int main()
{
    testGermin();
    return 0;
}